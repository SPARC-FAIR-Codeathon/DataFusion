def process(a,b):
    return a+b